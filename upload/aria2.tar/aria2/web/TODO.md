TODOS
=====
+ task options modify
+ offline